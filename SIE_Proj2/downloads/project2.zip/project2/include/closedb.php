<?php
    pg_close($conn);
?>